#ifndef ENGINE_ASSERT_H
#define ENGINE_ASSERT_H

#include <cassert>

#define ASSERT(condition) assert(condition)

#endif
