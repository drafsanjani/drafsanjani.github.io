#ifndef ENGINE_LOG_H
#define ENGINE_LOG_H

namespace M4
{

void Log_Error(const char* format, ...);

}

#endif
